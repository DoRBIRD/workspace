/*
 * main.h
 *
 *  Created on: 18.03.2015
 *      Author: Jonas
 */

#ifndef MAIN_H_
#define MAIN_H_





#endif /* MAIN_H_ */
void Preview(GLFWwindow* window){
	private:
		int speed;
};
